﻿using UnityEngine;
using System.Collections;

public class WG_Spawner : EnemySpawner {

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
