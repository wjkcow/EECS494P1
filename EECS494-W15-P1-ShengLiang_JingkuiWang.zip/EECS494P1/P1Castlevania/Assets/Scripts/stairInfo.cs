﻿using UnityEngine;
using System.Collections;

public class stairInfo : MonoBehaviour {
	public GameObject[] stairs;
	public GameObject[] startPos;
	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
