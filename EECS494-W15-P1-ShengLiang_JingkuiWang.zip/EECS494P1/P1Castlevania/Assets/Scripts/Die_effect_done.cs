﻿using UnityEngine;
using System.Collections;

public class Die_effect_done : MonoBehaviour {

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}
	public void done(){
		Destroy (this.gameObject);

	}
}
