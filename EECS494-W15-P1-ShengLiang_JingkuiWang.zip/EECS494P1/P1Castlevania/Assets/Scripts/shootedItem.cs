﻿using UnityEngine;
using System.Collections;

public class shootedItem : MonoBehaviour {
	public Vector3 acc;
	// Use this for initialization
	void Start () {
		transform.rigidbody2D.gravityScale = 0;
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
