﻿using UnityEngine;
using System.Collections;

public class wall_v : MonoBehaviour {

	public int dir_left;
	public bool boss = false;
}
